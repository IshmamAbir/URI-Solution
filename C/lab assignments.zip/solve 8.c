#include <stdio.h>
int main()
{
    int beg, end, mid, item, loc;
    int i, n;
    int ara[1002];

    printf("how many numbers: ");
    scanf("%d", &n);

    printf("Enter the numbers: ");
    for(i=1; i<=n; i++)
        scanf("%d", &ara[i]);

    printf("Enter the number to search: ");
    scanf("%d", &item);

    beg = ara[1];
    end = ara[n];
    mid = (beg + end) / 2;

    while(beg <= end && ara[mid] != item)
    {
        if(item < ara[mid])
            end = mid - 1;
        else
            beg = mid + 1;

        mid = (beg + end) / 2;
    }
    if(ara[mid] == item)
        loc = mid;
    else
        loc = NULL;

    printf("%d is the location of item.\n", loc);
}
