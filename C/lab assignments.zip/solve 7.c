#include <stdio.h>
int main()
{
    int ara[1000];
    int n, i, item;
    int loc = 1;

    printf("how many numbers: ");
    scanf("%d",&n);
    printf("Enter the numbers: ");
    for(i=1; i<=n; i++)
    {
        scanf("%d", &ara[i]);
    }
    printf("Enter the number to search: ");
    scanf("%d", &item);

    for(i=1; i<=n; i++)
    {
        if(item == ara[i])
            loc = i;
    }

    printf("%d is the location of item", loc);

    return 0;
}
