#include <stdio.h>
int main()
{
    int ara[1000], temp;
    int i, n, k, ptr;
    printf("how many numbers: ");
    scanf("%d",&n);
    printf("Enter the numbers: ");
    for(i=1; i<=n; i++)
    {
        scanf("%d", &ara[i]);
    }

    for(i=1; i < n; i++)
    {
        ptr = 1;
        while(ptr <= n-i)
        {
            if(ara[ptr] > ara[ptr+1])
            {
                temp = ara[ptr];
                ara[ptr] = ara[ptr+1];
                ara[ptr+1] = temp;
            }
         ptr++;
        }
    }

    for(i=1; i<=n; i++)
    {
        printf("%d\n", ara[i]);
    }
}
